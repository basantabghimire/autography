# AutograpgFRA
File Related API using aws s3 bucket
